plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "tech.granet.grove"
    compileSdk = 35
    defaultConfig {
        applicationId = "tech.granet.grove"
        minSdk = 31
        targetSdk = 35
        versionCode = 6
        versionName = "0.1.5-alpha"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.activity:activity-ktx:1.10.1")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")
}
