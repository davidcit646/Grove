package tech.granet.grove

import android.app.WallpaperManager
import android.app.role.RoleManager
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetProviderInfo
import android.content.*
import android.content.pm.LauncherApps
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.LayerDrawable
import android.net.Uri
import android.os.*
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.color.DynamicColors
import com.google.android.material.switchmaterial.SwitchMaterial
import java.util.*
import java.util.concurrent.Executors

/** Root HOME activity. Owns navigation; Android owns external apps and widget providers. */
class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("grove", MODE_PRIVATE) }
    private val launcher by lazy { getSystemService(LauncherApps::class.java) }
    private val manager by lazy { AppWidgetManager.getInstance(this) }
    private val host by lazy { AppWidgetHost(this, 1024) }
    private val worker = Executors.newSingleThreadExecutor()
    // Every installed app icon is decoded during app discovery and retained for the
    // lifetime of the launcher process. Drawer rendering never decodes icons.
    private val iconCache get() = AppIconStore.icons
    private var drawerAdapter: AppAdapter? = null
    private var drawerEmpty: TextView? = null
    private var drawerGrid: GridView? = null
    private var config = Config()
    private var apps = emptyList<App>()
    private var widgetIds = mutableListOf<Int>()
    private var pendingWidget = -1
    private var drawer = false
    private lateinit var root: LinearLayout
    private lateinit var body: LinearLayout
    private var searchField: EditText? = null
    private var loadGeneration = 0
    private var artworkStyle = -1
    private var artwork: Bitmap? = null
    private var gestureStartX = 0f
    private var gestureStartY = 0f
    private var gestureStartTime = 0L
    private var gestureTracking = false
    private var gestureBlocked = false
    private var contextMenuBlocked = false
    private var longPressTriggered = false
    private var touchMoved = false
    private var swipeCaptured = false
    private var drawerSwipeTracking = false
    private var drawerSwipeCaptured = false
    private var drawerStartedAtTop = false
    private var touchedScroll: ScrollView? = null
    private var loadingApps = true
    private val longPressHandler = Handler(Looper.getMainLooper())
    private val longPressRunnable = Runnable {
        if (gestureTracking && !drawer && !contextMenuBlocked && config.gestures.longPressHomeContextMenu) {
            longPressTriggered = true
            gestureTracking = false
            cancelChildTouch()
            settings()
        }
    }
    private data class App(val component: ComponentName, val label: String) {
        val key = component.flattenToString()
        val searchName = Search.normalize(label)
    }

    private val export = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) runCatching { contentResolver.openOutputStream(uri)?.use { it.write(config.json().toByteArray()) } ?: error("Cannot open file") }
            .onFailure { message("Could not export configuration") }
    }
    private val importConfig = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            val bytes = contentResolver.openInputStream(uri)?.use { input -> val buffer = java.io.ByteArrayOutputStream(); val chunk = ByteArray(4096); while (buffer.size() <= 65536) { val count = input.read(chunk, 0, minOf(chunk.size, 65537 - buffer.size())); if (count < 0) break; buffer.write(chunk, 0, count) }; buffer.toByteArray() } ?: error("Cannot open file")
            require(bytes.size <= 65536) { "Configuration exceeds 64 KB" }
            Config.parse(bytes.toString(Charsets.UTF_8))
        }.onSuccess { config = it; save(); showHome(); message("Configuration imported") }
            .onFailure { message(it.message ?: "Invalid configuration") }
    }
    private val bindWidget = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) configureWidget() else cancelWidget()
    }
    private val configureResult = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) finishWidget() else cancelWidget()
    }
    private val chooseHome = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { }
    private val changes = object : LauncherApps.Callback() {
        override fun onPackageAdded(p: String, u: UserHandle) = loadApps(p)
        override fun onPackageRemoved(p: String, u: UserHandle) = loadApps()
        override fun onPackageChanged(p: String, u: UserHandle) = loadApps(p)
        override fun onPackagesAvailable(p: Array<out String>, u: UserHandle, replacing: Boolean) = loadApps()
        override fun onPackagesUnavailable(p: Array<out String>, u: UserHandle, replacing: Boolean) = loadApps()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        DynamicColors.applyToActivityIfAvailable(this)
        super.onCreate(savedInstanceState)
        config = runCatching { Config.parse(prefs.getString("config", "")!!) }.getOrDefault(Config())
        widgetIds = prefs.getStringSet("widgets", emptySet())!!.mapNotNull { it.toIntOrNull() }.sorted().toMutableList()
        pendingWidget = savedInstanceState?.getInt("pending", -1) ?: prefs.getInt("pending", -1)
        // Recover orphan allocation after process death with no pending activity result.
        if (savedInstanceState == null && pendingWidget != -1) cancelWidget()
        window.setDecorFitsSystemWindows(false)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.setOnApplyWindowInsetsListener { v, insets ->
            val edges = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
            v.setPadding(dp(20), edges.top + dp(12), dp(20), edges.bottom + dp(12)); insets
        }
        setContentView(root)
        onBackPressedDispatcher.addCallback(this, object : androidx.activity.OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { showHome() }
        })
        launcher.registerCallback(changes, Handler(Looper.getMainLooper()))
        showHome(); loadApps()
        if (intent.hasCategory(Intent.CATEGORY_LAUNCHER) || intent.action == Intent.ACTION_APPLICATION_PREFERENCES) root.post { settings() }
    }
    override fun onStart() { super.onStart(); host.startListening() }
    override fun onStop() { longPressHandler.removeCallbacks(longPressRunnable); gestureTracking = false; host.stopListening(); super.onStop() }
    override fun onDestroy() { launcher.unregisterCallback(changes); longPressHandler.removeCallbacks(longPressRunnable); worker.shutdownNow(); super.onDestroy() }
    override fun onSaveInstanceState(outState: Bundle) { outState.putInt("pending", pendingWidget); super.onSaveInstanceState(outState) }
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent); setIntent(intent); showHome()
        if (intent.hasCategory(Intent.CATEGORY_LAUNCHER) || intent.action == Intent.ACTION_APPLICATION_PREFERENCES) root.post { settings() }
    }

    private fun cancelChildTouch() {
        val cancel = MotionEvent.obtain(gestureStartTime, SystemClock.uptimeMillis(), MotionEvent.ACTION_CANCEL, 0f, 0f, 0)
        super.dispatchTouchEvent(cancel); cancel.recycle()
    }
    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                root.animate().cancel()
                root.translationY = 0f
                root.alpha = 1f
                gestureStartX = event.rawX; gestureStartY = event.rawY; gestureStartTime = event.eventTime
                longPressTriggered = false; touchMoved = false; swipeCaptured = false
                drawerSwipeCaptured = false
                longPressHandler.removeCallbacks(longPressRunnable)

                if (drawer) {
                    val grid = drawerGrid
                    drawerStartedAtTop = grid != null && !grid.canScrollVertically(-1) && pointInside(grid, event.rawX, event.rawY)
                    drawerSwipeTracking = drawerStartedAtTop
                    gestureTracking = false
                    return super.dispatchTouchEvent(event)
                }

                drawerSwipeTracking = false
                gestureTracking = ::root.isInitialized
                gestureBlocked = gestureTracking && touchInsideWidget(root, event.rawX, event.rawY)
                contextMenuBlocked = gestureTracking && touchInsideInteractive(root, event.rawX, event.rawY)
                touchedScroll = if (gestureTracking) scrollAt(root, event.rawX, event.rawY) else null
                if (gestureTracking && !contextMenuBlocked && config.gestures.longPressHomeContextMenu) {
                    longPressHandler.postDelayed(longPressRunnable, ViewConfiguration.getLongPressTimeout().toLong())
                }
            }
            MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_CANCEL -> {
                longPressHandler.removeCallbacks(longPressRunnable)
                gestureTracking = false
                drawerSwipeTracking = false
                settleSwipeFeedback()
                if (swipeCaptured || drawerSwipeCaptured || longPressTriggered) {
                    swipeCaptured = false; drawerSwipeCaptured = false; longPressTriggered = false
                    return true
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (drawerSwipeTracking) {
                    val dx = event.rawX - gestureStartX; val dy = event.rawY - gestureStartY
                    val slop = ViewConfiguration.get(this).scaledTouchSlop.toFloat()
                    if (!drawerSwipeCaptured && dy > slop && kotlin.math.abs(dy) > kotlin.math.abs(dx) * 1.1f) {
                        drawerSwipeCaptured = true
                        cancelChildTouch()
                    }
                    if (drawerSwipeCaptured) {
                        val offset = dy.coerceAtLeast(0f) * 0.72f
                        root.translationY = offset
                        root.alpha = (1f - (offset / maxOf(root.height.toFloat(), 1f)) * 0.35f).coerceAtLeast(0.78f)
                        return true
                    }
                }

                if (longPressTriggered) return true
                if (gestureTracking) {
                    val dx = event.rawX - gestureStartX; val dy = event.rawY - gestureStartY
                    val slop = ViewConfiguration.get(this).scaledTouchSlop.toFloat()
                    if (dx * dx + dy * dy > slop * slop) {
                        touchMoved = true; longPressHandler.removeCallbacks(longPressRunnable)
                        if (!swipeCaptured && touchedScroll?.canScrollVertically(if (dy > 0) -1 else 1) == true) gestureBlocked = true
                    }
                    if (!gestureBlocked && !contextMenuBlocked) {
                        val preview = (dy * 0.10f).coerceIn(-dp(24).toFloat(), dp(24).toFloat())
                        root.translationY = preview
                        root.alpha = 0.98f
                    }
                    if (!gestureBlocked && !swipeCaptured && Gestures.resolve(dx, dy, event.eventTime - gestureStartTime,
                            dp(72).toFloat(), config.gestures) != HomeGesture.NONE) {
                        swipeCaptured = true; cancelChildTouch()
                    }
                    if (swipeCaptured) return true
                }
            }
            MotionEvent.ACTION_UP -> {
                longPressHandler.removeCallbacks(longPressRunnable)

                if (drawerSwipeTracking || drawerSwipeCaptured) {
                    drawerSwipeTracking = false
                    val dx = event.rawX - gestureStartX; val dy = event.rawY - gestureStartY
                    val close = drawerSwipeCaptured && Gestures.drawerClose(
                        dx, dy, event.eventTime - gestureStartTime, dp(88).toFloat(), drawerStartedAtTop
                    )
                    drawerSwipeCaptured = false
                    if (close) {
                        animateDrawerClosed()
                        return true
                    }
                    settleSwipeFeedback()
                    if (drawerStartedAtTop && dy > ViewConfiguration.get(this).scaledTouchSlop) return true
                }

                if (longPressTriggered) {
                    longPressTriggered = false; gestureTracking = false; settleSwipeFeedback(); return true
                }
                if (gestureTracking) {
                    gestureTracking = false
                    val dx = event.rawX - gestureStartX; val dy = event.rawY - gestureStartY
                    val gesture = if (!gestureBlocked) Gestures.resolve(dx, dy, event.eventTime - gestureStartTime,
                        dp(72).toFloat(), config.gestures) else HomeGesture.NONE
                    if (gesture != HomeGesture.NONE) {
                        if (!swipeCaptured) cancelChildTouch()
                        swipeCaptured = false
                        animateHomeGesture(gesture)
                        return true
                    }
                    settleSwipeFeedback()
                    if (swipeCaptured) { swipeCaptured = false; return true }
                    val slop = ViewConfiguration.get(this).scaledTouchSlop.toFloat()
                    val tap = !touchMoved && dx * dx + dy * dy <= slop * slop && event.eventTime - gestureStartTime <= 350L
                    if (!contextMenuBlocked && tap && config.gestures.tapHomeContextMenu) {
                        cancelChildTouch(); settings(); return true
                    }
                }
            }
        }
        return super.dispatchTouchEvent(event)
    }

    private fun pointInside(view: View, rawX: Float, rawY: Float): Boolean {
        val location = IntArray(2)
        view.getLocationOnScreen(location)
        return rawX >= location[0] && rawX < location[0] + view.width &&
            rawY >= location[1] && rawY < location[1] + view.height
    }

    private fun settleSwipeFeedback() {
        root.animate().cancel()
        root.animate().translationY(0f).alpha(1f).setDuration(140L).start()
    }

    private fun animateHomeGesture(gesture: HomeGesture) {
        val direction = if (gesture == HomeGesture.SEARCH) 1f else -1f
        root.animate().cancel()
        root.animate().translationY(direction * dp(30)).alpha(0.72f).setDuration(110L).withEndAction {
            when (gesture) {
                HomeGesture.SEARCH -> showDrawer(true, animate = true)
                HomeGesture.APP_DRAWER -> showDrawer(false, animate = true)
                else -> settleSwipeFeedback()
            }
        }.start()
    }

    private fun animateDrawerClosed() {
        root.animate().cancel()
        root.animate().translationY(dp(72).toFloat()).alpha(0f).setDuration(130L).withEndAction {
            showHome(animate = true)
        }.start()
    }
    private fun scrollAt(view: View, x: Float, y: Float): ScrollView? {
        val bounds = Rect()
        if (!view.getGlobalVisibleRect(bounds) || !bounds.contains(x.toInt(), y.toInt())) return null
        if (view is ScrollView) return view
        if (view is ViewGroup) for (index in 0 until view.childCount) {
            scrollAt(view.getChildAt(index), x, y)?.let { return it }
        }
        return null
    }

    private fun touchInsideWidget(view: View, rawX: Float, rawY: Float): Boolean {
        if (view.visibility != View.VISIBLE) return false
        if (view is AppWidgetHostView) {
            val location = IntArray(2)
            view.getLocationOnScreen(location)
            return rawX >= location[0] && rawX < location[0] + view.width &&
                rawY >= location[1] && rawY < location[1] + view.height
        }
        if (view is ViewGroup) {
            for (index in 0 until view.childCount) {
                if (touchInsideWidget(view.getChildAt(index), rawX, rawY)) return true
            }
        }
        return false
    }

    private fun touchInsideInteractive(view: View, rawX: Float, rawY: Float): Boolean {
        if (view.visibility != View.VISIBLE) return false
        if (view !== root && (view.isClickable || view.isLongClickable || view is EditText || view is AppWidgetHostView)) {
            val location = IntArray(2)
            view.getLocationOnScreen(location)
            if (rawX >= location[0] && rawX < location[0] + view.width &&
                rawY >= location[1] && rawY < location[1] + view.height) return true
        }
        if (view is ViewGroup) {
            for (index in 0 until view.childCount) {
                if (touchInsideInteractive(view.getChildAt(index), rawX, rawY)) return true
            }
        }
        return false
    }

    private fun loadApps(changedPackage: String? = null) {
        if (isDestroyed || worker.isShutdown) return
        val generation = ++loadGeneration
        val iconSize = dp(48)
        AppIconStore.useSize(iconSize)
        val reusable = iconCache.filterKeys { ComponentName.unflattenFromString(it)?.packageName != changedPackage }
        worker.execute {
            val result = runCatching {
                val loadedApps = launcher.getActivityList(null, android.os.Process.myUserHandle())
                    .filter { it.componentName.packageName != packageName }
                    .map { App(it.componentName, it.label.toString()) }
                    .sortedBy { Search.normalize(it.label) }
                val fallbackIcon = Bitmap.createBitmap(iconSize, iconSize, Bitmap.Config.ARGB_8888).also { bitmap ->
                    packageManager.defaultActivityIcon.apply { setBounds(0, 0, iconSize, iconSize); draw(Canvas(bitmap)) }
                }
                val loadedIcons = HashMap<String, Bitmap>(loadedApps.size)
                loadedApps.forEach { app ->
                    val cached = reusable[app.key]
                    if (cached != null) { loadedIcons[app.key] = cached; return@forEach }
                    runCatching {
                        val drawable = packageManager.getActivityIcon(app.component)
                        Bitmap.createBitmap(iconSize, iconSize, Bitmap.Config.ARGB_8888).also { bitmap ->
                            drawable.setBounds(0, 0, iconSize, iconSize)
                            drawable.draw(Canvas(bitmap))
                        }
                    }.getOrDefault(fallbackIcon).let { loadedIcons[app.key] = it }
                }
                loadedApps to loadedIcons
            }
            runOnUiThread {
                if (isDestroyed || generation != loadGeneration) return@runOnUiThread
                result.onSuccess { (loadedApps, loadedIcons) ->
                    iconCache.clear()
                    iconCache.putAll(loadedIcons)
                    apps = loadedApps
                    loadingApps = false
                    if (!prefs.contains("initialized")) {
                        if (config.favorites.isEmpty()) config = config.copy(favorites = apps.take(8).map { app -> app.key })
                        prefs.edit().putBoolean("initialized", true).apply(); save()
                    }
                    if (drawer) renderApps(searchField?.text?.toString().orEmpty()) else showHome()
                }.onFailure { loadingApps = false; message("Unable to load apps"); if (drawer) renderApps(searchField?.text?.toString().orEmpty()) }
            }
        }
    }
    private fun save() { prefs.edit().putString("config", config.json()).apply() }
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun message(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()
    private fun label(text: String, size: Float = 16f) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(Color.WHITE); setPadding(0, dp(8), 0, dp(8))
    }
    private fun button(text: String, action: () -> Unit) = MaterialButton(this).apply { this.text = text; setOnClickListener { action() } }
    private fun base() {
        searchField = null; drawerAdapter = null; drawerEmpty = null; drawerGrid = null
        root.animate().cancel(); root.translationY = 0f; root.alpha = 1f
        root.removeAllViews()
        if (artworkStyle != config.wallpaper) {
            artwork = WallpaperArt.create(config.wallpaper)
            artworkStyle = config.wallpaper
        }
        root.background = LayerDrawable(arrayOf(
            BitmapDrawable(resources, artwork!!).apply { gravity = Gravity.FILL },
            GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x66000000, 0xaa000000.toInt()))
        ))
    }
    private fun scrollBody() {
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { isFillViewport = true; addView(body) }, LinearLayout.LayoutParams(-1, 0, 1f))
    }
    private fun openSearch() = showDrawer(true, animate = true)
    private fun openAppDrawer() = showDrawer(false, animate = true)

    private fun enterContent(fromY: Float) {
        root.alpha = 0f
        root.translationY = fromY
        root.animate().translationY(0f).alpha(1f).setDuration(170L).start()
    }

    private fun showHome(animate: Boolean = false) {
        getSystemService(android.view.inputmethod.InputMethodManager::class.java).hideSoftInputFromWindow(root.windowToken, 0)
        drawer = false; base()
        if (config.homeScreen.showClock) {
            root.addView(TextClock(this).apply { format12Hour = "h:mm"; format24Hour = "HH:mm"; textSize = 58f; setTextColor(Color.WHITE) })
            root.addView(TextClock(this).apply { format12Hour = "EEEE, MMMM d"; format24Hour = "EEEE, MMMM d"; textSize = 16f; setTextColor(Color.WHITE); setPadding(0, dp(8), 0, dp(8)) })
        }
        if (config.homeScreen.showSearchButton) root.addView(button("Search apps") { openSearch() })
        scrollBody()
        if (config.homeScreen.showPinnedApps && !config.homeScreen.pinnedAppsAtBottom) renderPinnedApps()
        renderWidgets()
        if (config.homeScreen.showPinnedApps && config.homeScreen.pinnedAppsAtBottom) renderPinnedApps()
        if (config.homeScreen.showAppsButton) {
            root.addView(button("All apps") { openAppDrawer() })
        }
        if (animate) enterContent(-dp(24).toFloat())
    }

    private fun renderPinnedApps() {
        val heading = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        heading.addView(label("PINNED APPS", 12f), LinearLayout.LayoutParams(0, -2, 1f))
        if (config.favorites.size > 1) heading.addView(button("Arrange") { arrangePinnedApps() })
        body.addView(heading)
        body.addView(label("Long-press any app for options.", 12f))
        addGrid(apps.filter { it.key in config.favorites }.sortedBy { config.favorites.indexOf(it.key) }, body)
        if (config.favorites.isEmpty()) body.addView(label("Long-press an app in the drawer to pin it here."))
    }

    private fun showDrawer(keyboard: Boolean, animate: Boolean = false) {
        drawer = true; base()
        root.addView(label("All apps", 30f))
        val field = EditText(this).apply {
            hint = "Search installed apps"; setSingleLine(); setTextColor(Color.WHITE); setHintTextColor(0xffc1ccc5.toInt())
            contentDescription = "Search installed apps"
        }
        searchField = field; root.addView(field)
        val content = FrameLayout(this)
        val empty = label(if (loadingApps) "Preparing apps and icons…" else "No matching apps").apply { gravity = Gravity.CENTER }
        drawerEmpty = empty
        val grid = GridView(this).apply {
            numColumns = if (resources.configuration.screenWidthDp >= 600) 6 else 4
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            verticalSpacing = dp(4)
            clipToPadding = false
        }
        drawerGrid = grid
        drawerAdapter = AppAdapter()
        grid.adapter = drawerAdapter
        content.addView(grid, FrameLayout.LayoutParams(-1, -1))
        content.addView(empty, FrameLayout.LayoutParams(-1, -1))
        grid.emptyView = empty
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        field.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderApps(s.toString()) }
            override fun afterTextChanged(s: Editable?) {}
        })
        renderApps("")
        root.addView(button("Home") { showHome(animate = true) })
        if (animate) enterContent(dp(26).toFloat())
        if (keyboard) { field.requestFocus(); field.post { getSystemService(android.view.inputmethod.InputMethodManager::class.java).showSoftInput(field, 0) } }
    }
    private fun renderApps(query: String) {
        drawerEmpty?.text = if (loadingApps) "Preparing apps and icons…" else "No matching apps"
        val prepared = Search.prepare(query)
        val filtered = if (prepared.text.isEmpty()) apps else apps
            .map { it to Search.scoreNormalized(it.searchName, prepared) }
            .filter { it.second >= 0 }.sortedByDescending { it.second }.map { it.first }
        drawerAdapter?.submit(filtered)
    }
    private class Tile(val layout: LinearLayout, val icon: ImageView, val name: TextView)
    private fun createTile(): Tile {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(4), dp(10), dp(4), dp(10))
            isFocusable = true; isClickable = true
        }
        val icon = ImageView(this).apply { importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO }
        val name = label("", 12f).apply { gravity = Gravity.CENTER; maxLines = 2; minLines = 2 }
        layout.addView(icon, LinearLayout.LayoutParams(dp(48), dp(48)))
        layout.addView(name)
        return Tile(layout, icon, name).also { layout.tag = it }
    }
    private fun bindTile(tile: Tile, app: App) {
        tile.layout.contentDescription = app.label; tile.name.text = app.label
        bindIcon(tile.icon, app)
        tile.layout.setOnClickListener {
            runCatching { launcher.startMainActivity(app.component, android.os.Process.myUserHandle(), null, null) }
                .onFailure { message("This app is unavailable"); loadApps() }
        }
        tile.layout.setOnLongClickListener { appMenu(app); true }
    }
    private fun bindIcon(view: ImageView, app: App) {
        view.tag = app.key
        val cached = iconCache[app.key]
        view.setImageBitmap(cached)
    }
    private inner class AppAdapter : BaseAdapter() {
        private var items = emptyList<App>()
        fun submit(next: List<App>) { items = next; notifyDataSetChanged() }
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val tile = (convertView?.tag as? Tile) ?: createTile()
            bindTile(tile, items[position]); return tile.layout
        }
    }
    private fun addGrid(items: List<App>, target: LinearLayout) {
        val columns = if (resources.configuration.screenWidthDp >= 600) 6 else 4
        items.chunked(columns).forEach { group ->
            val row = LinearLayout(this)
            group.forEach { app ->
                val tile = createTile(); bindTile(tile, app)
                row.addView(tile.layout, LinearLayout.LayoutParams(0, -2, 1f))
            }
            repeat(columns - group.size) { row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f)) }
            target.addView(row)
        }
    }
    private fun arrangePinnedApps() {
        if (config.favorites.size < 2) return
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(4), dp(12), dp(4))
        }
        val appByKey = apps.associateBy { it.key }
        lateinit var redraw: () -> Unit

        fun commit(next: List<String>) {
            config = config.copy(favorites = next.distinct())
            save()
            redraw()
        }

        redraw = {
            content.removeAllViews()
            content.addView(label("Drag the handle onto another app, or use Earlier/Later.", 12f))
            config.favorites.forEach { key ->
                val app = appByKey[key] ?: return@forEach
                val row = LinearLayout(this).apply {
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(4), dp(5), dp(4), dp(5))
                }
                val handle = TextView(this).apply {
                    text = "↕"
                    textSize = 24f
                    gravity = Gravity.CENTER
                    contentDescription = "Drag ${app.label}"
                    setPadding(dp(10), dp(8), dp(10), dp(8))
                    isLongClickable = true
                    setOnLongClickListener {
                        val data = ClipData.newPlainText("grove-pinned-app", key)
                        startDragAndDrop(data, View.DragShadowBuilder(row), key, 0)
                        true
                    }
                }
                val icon = ImageView(this).apply {
                    importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                    setImageBitmap(iconCache[key])
                }
                val title = TextView(this).apply {
                    text = app.label
                    textSize = 15f
                    setPadding(dp(10), 0, dp(8), 0)
                }
                row.addView(handle, LinearLayout.LayoutParams(dp(48), dp(52)))
                row.addView(icon, LinearLayout.LayoutParams(dp(40), dp(40)))
                row.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(button("Earlier") { commit(PinnedApps.shift(config.favorites, key, -1)) })
                row.addView(button("Later") { commit(PinnedApps.shift(config.favorites, key, 1)) })
                row.setOnDragListener { target, event ->
                    when (event.action) {
                        DragEvent.ACTION_DRAG_ENTERED -> {
                            target.setBackgroundColor(0x33ffffff)
                            true
                        }
                        DragEvent.ACTION_DRAG_EXITED, DragEvent.ACTION_DRAG_ENDED -> {
                            target.setBackgroundColor(Color.TRANSPARENT)
                            true
                        }
                        DragEvent.ACTION_DROP -> {
                            target.setBackgroundColor(Color.TRANSPARENT)
                            val dragged = event.localState as? String ?: event.clipData?.getItemAt(0)?.text?.toString()
                            if (dragged != null) commit(PinnedApps.moveTo(config.favorites, dragged, key))
                            true
                        }
                        else -> true
                    }
                }
                content.addView(row, LinearLayout.LayoutParams(-1, -2))
            }
        }
        redraw()

        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle("Arrange pinned apps")
            .setView(ScrollView(this).apply { addView(content) })
            .setPositiveButton("Done", null)
            .create()
        dialog.setOnDismissListener { if (!drawer) showHome() }
        dialog.show()
    }

    private fun appMenu(app: App) {
        val pinned = app.key in config.favorites
        val actions = buildList {
            add(if (pinned) "Unpin from home" else "Pin to home")
            if (pinned && config.favorites.size > 1) add("Arrange pinned apps")
            add("App info")
            add("Uninstall")
        }
        MaterialAlertDialogBuilder(this).setTitle(app.label).setItems(actions.toTypedArray()) { _, index ->
            when (actions[index]) {
                "Unpin from home", "Pin to home" -> {
                    config = config.copy(favorites = if (pinned) config.favorites - app.key else config.favorites + app.key)
                    save(); if (!drawer) showHome()
                }
                "Arrange pinned apps" -> arrangePinnedApps()
                "App info" -> runCatching { launcher.startAppDetailsActivity(app.component, android.os.Process.myUserHandle(), null, null) }
                    .onFailure { message("App information unavailable") }
                "Uninstall" -> runCatching {
                    startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.component.packageName}")))
                }.onFailure { message("This app cannot be uninstalled") }
            }
        }.show()
    }
    private fun settings() {
        MaterialAlertDialogBuilder(this).setTitle("Grove settings").setItems(arrayOf("Launcher settings", "Set as default launcher", "Add widget", "Wallpapers", "Edit configuration", "Export configuration", "Import configuration", "About Grove")) { _, index ->
            when(index) {
                0 -> launcherSettings()
                1 -> { val role = getSystemService(RoleManager::class.java); if (role.isRoleAvailable(RoleManager.ROLE_HOME)) chooseHome.launch(role.createRequestRoleIntent(RoleManager.ROLE_HOME)) }
                2 -> pickWidget()
                3 -> wallpapers()
                4 -> editConfig()
                5 -> export.launch("grove-config.json")
                6 -> importConfig.launch(arrayOf("application/json", "text/plain", "application/octet-stream"))
                7 -> MaterialAlertDialogBuilder(this).setTitle("Grove · 0.1.5 alpha").setMessage("A quiet place to start.\n\nFree and open source · Apache 2.0\nNo telemetry. No network permission.\n\nSwipe down for search and swipe up for all apps when enabled. Swipe down from the top of the app drawer to close it. Pinned apps can be arranged and placed near the top or bottom of Home.").setPositiveButton("Done", null).show()
            }
        }.show()
    }

    private fun launcherSettings() {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(4), dp(20), dp(4))
        }

        fun section(title: String) {
            content.addView(TextView(this).apply {
                text = title
                textSize = 14f
                setTypeface(typeface, Typeface.BOLD)
                setPadding(0, dp(16), 0, dp(4))
            })
        }

        fun toggle(text: String, checked: Boolean, changed: (Boolean) -> Unit) {
            content.addView(SwitchMaterial(this).apply {
                this.text = text
                isChecked = checked
                setPadding(0, dp(4), 0, dp(4))
                setOnCheckedChangeListener { _, value -> changed(value) }
            }, LinearLayout.LayoutParams(-1, -2))
        }

        fun commit(next: Config) {
            config = next
            save()
            if (!drawer) showHome()
        }

        section("Gestures")
        toggle("Swipe down to search", config.gestures.swipeDownSearch) { enabled ->
            commit(config.copy(gestures = config.gestures.copy(swipeDownSearch = enabled)))
        }
        toggle("Swipe up for app drawer", config.gestures.swipeUpAppDrawer) { enabled ->
            commit(config.copy(gestures = config.gestures.copy(swipeUpAppDrawer = enabled)))
        }
        toggle("Tap home screen for launcher menu", config.gestures.tapHomeContextMenu) { enabled ->
            commit(config.copy(gestures = config.gestures.copy(tapHomeContextMenu = enabled)))
        }
        toggle("Tap and hold home screen for launcher menu", config.gestures.longPressHomeContextMenu) { enabled ->
            commit(config.copy(gestures = config.gestures.copy(longPressHomeContextMenu = enabled)))
        }

        section("Home screen")
        toggle("Show Apps button", config.homeScreen.showAppsButton) { enabled ->
            commit(config.copy(homeScreen = config.homeScreen.copy(showAppsButton = enabled)))
        }
        toggle("Show Search button", config.homeScreen.showSearchButton) { enabled ->
            commit(config.copy(homeScreen = config.homeScreen.copy(showSearchButton = enabled)))
        }
        toggle("Show clock and date", config.homeScreen.showClock) { enabled ->
            commit(config.copy(homeScreen = config.homeScreen.copy(showClock = enabled)))
        }
        toggle("Show pinned apps", config.homeScreen.showPinnedApps) { enabled ->
            commit(config.copy(homeScreen = config.homeScreen.copy(showPinnedApps = enabled)))
        }
        toggle("Pinned apps at bottom", config.homeScreen.pinnedAppsAtBottom) { enabled ->
            commit(config.copy(homeScreen = config.homeScreen.copy(pinnedAppsAtBottom = enabled)))
        }

        content.addView(TextView(this).apply {
            text = "Tap and hold empty home space to open this menu when enabled. If all controls are hidden, open Grove from another launcher’s app list or its Android app settings shortcut to restore them. Widgets remain until removed."
            setPadding(0, dp(16), 0, dp(12))
        })
        MaterialAlertDialogBuilder(this)
            .setTitle("Launcher settings")
            .setView(ScrollView(this).apply { addView(content) })
            .setPositiveButton("Done", null)
            .show()
    }
    private fun editConfig() {
        val editor = EditText(this).apply { setText(config.json()); typeface = Typeface.MONOSPACE; minLines = 8 }
        val dialog = MaterialAlertDialogBuilder(this).setTitle("Configuration").setView(editor).setNegativeButton("Cancel", null).setPositiveButton("Save", null).create()
        dialog.setOnShowListener { dialog.getButton(-1).setOnClickListener {
            runCatching { require(editor.length() <= 65536); Config.parse(editor.text.toString()) }
                .onSuccess { config = it; save(); dialog.dismiss(); showHome() }.onFailure { editor.error = it.message ?: "Invalid JSON" }
        } }; dialog.show()
    }

    // Widget lifecycle: allocate -> bind consent -> optional configuration -> persist.
    private fun pickWidget() {
        if (pendingWidget != -1) { message("Finish adding the current widget first"); return }
        val providers = manager.installedProviders.sortedBy { it.loadLabel(packageManager).lowercase() }
        MaterialAlertDialogBuilder(this).setTitle("Add widget").setItems(providers.map { it.loadLabel(packageManager) }.toTypedArray()) { _, index ->
            val provider = providers[index]
            pendingWidget = host.allocateAppWidgetId(); prefs.edit().putInt("pending", pendingWidget).apply()
            if (manager.bindAppWidgetIdIfAllowed(pendingWidget, provider.provider)) configureWidget()
            else runCatching { bindWidget.launch(Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingWidget).putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, provider.provider)) }
                .onFailure { cancelWidget(); message("Cannot bind this widget") }
        }.setNegativeButton("Cancel", null).show()
    }
    private fun configureWidget() {
        val info = manager.getAppWidgetInfo(pendingWidget) ?: return cancelWidget()
        if (info.configure != null) {
            runCatching { configureResult.launch(Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE).setComponent(info.configure)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingWidget)) }
                .onFailure { cancelWidget(); message("Widget configuration unavailable") }
        } else finishWidget()
    }
    private fun finishWidget() {
        if (pendingWidget != -1 && manager.getAppWidgetInfo(pendingWidget) != null) {
            if (pendingWidget !in widgetIds) widgetIds.add(pendingWidget)
            prefs.edit().putStringSet("widgets", widgetIds.map { it.toString() }.toSet()).apply()
        } else if (pendingWidget != -1) host.deleteAppWidgetId(pendingWidget)
        pendingWidget = -1; prefs.edit().remove("pending").apply(); showHome()
    }
    private fun cancelWidget() {
        if (pendingWidget != -1) host.deleteAppWidgetId(pendingWidget)
        pendingWidget = -1; prefs.edit().remove("pending").apply()
    }
    private fun renderWidgets() {
        widgetIds.forEach { id ->
            val info = manager.getAppWidgetInfo(id)
            val controls = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            controls.addView(label(info?.loadLabel(packageManager) ?: "Widget unavailable", 12f), LinearLayout.LayoutParams(0, -2, 1f))
            controls.addView(button("Edit") {
                MaterialAlertDialogBuilder(this).setTitle("Widget").setItems(arrayOf("Compact", "Medium", "Tall", "Remove")) { _, choice ->
                    if (choice == 3) { host.deleteAppWidgetId(id); widgetIds.remove(id); prefs.edit().putStringSet("widgets", widgetIds.map { it.toString() }.toSet()).remove("height_$id").apply() }
                    else prefs.edit().putInt("height_$id", listOf(140, 240, 360)[choice]).apply()
                    showHome()
                }.show()
            })
            body.addView(controls)
            if (info != null) runCatching {
                val height = maxOf(prefs.getInt("height_$id", 200), (info.minHeight / resources.displayMetrics.density).toInt())
                val widget = host.createView(this, id, info)
                body.addView(widget, LinearLayout.LayoutParams(-1, dp(height)))
                widget.post { if (widget.width > 0) widget.updateAppWidgetSize(null, (widget.width / resources.displayMetrics.density).toInt(), height, (widget.width / resources.displayMetrics.density).toInt(), height) }
            }.onFailure { body.addView(label("This widget could not be displayed.")) }
        }
    }

    private fun wallpapers() {
        MaterialAlertDialogBuilder(this).setTitle("Wallpapers").setItems(arrayOf("Fern · abstract", "Ember · mountain", "Dusk · mountain")) { _, index ->
            config = config.copy(wallpaper = index); save(); showHome()
            worker.execute {
                runCatching {
                    val bitmap = WallpaperArt.create(index)
                    try { WallpaperManager.getInstance(this).setBitmap(bitmap, null, true, WallpaperManager.FLAG_SYSTEM) } finally { bitmap.recycle() }
                }.onSuccess { runOnUiThread { if (!isDestroyed) message("Wallpaper applied") } }
                    .onFailure { runOnUiThread { if (!isDestroyed) message("Theme updated; system wallpaper could not be changed") } }
            }
        }.setNegativeButton("Cancel", null).show()
    }
}
