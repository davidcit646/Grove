package tech.granet.grove

import org.json.JSONArray
import org.json.JSONObject

/** Gesture behavior for the launcher home screen. */
data class GestureSettings(
    val swipeDownSearch: Boolean = true,
    val swipeUpAppDrawer: Boolean = true,
    val tapHomeContextMenu: Boolean = false,
    val longPressHomeContextMenu: Boolean = true,
)

/** Visibility and placement of optional home-screen elements. */
data class HomeScreenSettings(
    val showAppsButton: Boolean = true,
    val showSearchButton: Boolean = true,
    val showClock: Boolean = true,
    val showPinnedApps: Boolean = true,
    // True preserves the original Grove layout: pins sit after widgets and above All apps.
    // False moves pins directly below the clock/search controls.
    val pinnedAppsAtBottom: Boolean = true,
)

/** Persistent user settings. Widget IDs are device-local and deliberately excluded from exports. */
data class Config(
    val favorites: List<String> = emptyList(),
    val wallpaper: Int = 0,
    val gestures: GestureSettings = GestureSettings(),
    val homeScreen: HomeScreenSettings = HomeScreenSettings(),
) {
    fun json(): String = JSONObject()
        .put("version", 4)
        .put("wallpaper", wallpaper)
        .put("favorites", JSONArray(favorites))
        .put(
            "gestures",
            JSONObject()
                .put("swipeDownSearch", gestures.swipeDownSearch)
                .put("swipeUpAppDrawer", gestures.swipeUpAppDrawer)
                .put("tapHomeContextMenu", gestures.tapHomeContextMenu)
                .put("longPressHomeContextMenu", gestures.longPressHomeContextMenu),
        )
        .put(
            "homeScreen",
            JSONObject()
                .put("showAppsButton", homeScreen.showAppsButton)
                .put("showSearchButton", homeScreen.showSearchButton)
                .put("showClock", homeScreen.showClock)
                .put("showPinnedApps", homeScreen.showPinnedApps)
                .put("pinnedAppsAtBottom", homeScreen.pinnedAppsAtBottom),
        )
        .toString(2)

    companion object {
        fun parse(text: String): Config {
            val root = JSONObject(text)
            val version = root.getInt("version")
            require(version in 1..4) { "Unsupported configuration version" }

            val wallpaper = root.getInt("wallpaper")
            require(wallpaper in 0..2) { "Wallpaper must be 0, 1, or 2" }

            val entries = root.getJSONArray("favorites")
            require(entries.length() <= 100) { "Too many favorites" }
            val favorites = (0 until entries.length()).map { entries.getString(it) }
            require(favorites.all { it.length in 3..512 && it.contains('/') }) { "Invalid app identifier" }

            // Older versions had fewer gesture/home controls. Defaults deliberately preserve
            // their existing layout and behavior when imported into the current schema.
            fun section(name: String): JSONObject? {
                if (!root.has(name)) return null
                require(root.get(name) is JSONObject) { "$name must be an object" }
                return root.getJSONObject(name)
            }
            fun flag(section: JSONObject?, name: String, default: Boolean): Boolean {
                if (section == null || !section.has(name)) return default
                val value = section.get(name)
                require(value is Boolean) { "$name must be true or false" }
                return value
            }
            val gestureJson = section("gestures")
            val gestures = GestureSettings(
                swipeDownSearch = flag(gestureJson, "swipeDownSearch", true),
                swipeUpAppDrawer = flag(gestureJson, "swipeUpAppDrawer", true),
                tapHomeContextMenu = flag(gestureJson, "tapHomeContextMenu", false),
                longPressHomeContextMenu = flag(gestureJson, "longPressHomeContextMenu", true),
            )

            val homeJson = section("homeScreen")
            val homeScreen = HomeScreenSettings(
                showAppsButton = flag(homeJson, "showAppsButton", true),
                showSearchButton = flag(homeJson, "showSearchButton", true),
                showClock = flag(homeJson, "showClock", true),
                showPinnedApps = flag(homeJson, "showPinnedApps", true),
                pinnedAppsAtBottom = flag(homeJson, "pinnedAppsAtBottom", true),
            )

            return Config(favorites.distinct(), wallpaper, gestures, homeScreen)
        }
    }
}
