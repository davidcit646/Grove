package tech.granet.grove

import java.text.Normalizer
import java.util.Locale

/** Normalize app labels once at discovery; prepare each query once per text change. */
object Search {
    private val marks = Regex("\\p{M}+")
    private val whitespace = Regex("\\s+")
    data class Query(val text: String, val terms: List<String>)
    fun normalize(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFD)
        .replace(marks, "").lowercase(Locale.ROOT).trim()
    fun prepare(value: String): Query {
        val text = normalize(value)
        return Query(text, text.split(whitespace).filter { it.isNotEmpty() })
    }
    fun score(label: String, query: String): Int = scoreNormalized(normalize(label), prepare(query))
    fun scoreNormalized(label: String, query: Query): Int {
        if (query.terms.isEmpty()) return 0
        if (!query.terms.all { label.contains(it) }) return -1
        return if (label == query.text) 3 else if (label.startsWith(query.text)) 2 else 1
    }
}
