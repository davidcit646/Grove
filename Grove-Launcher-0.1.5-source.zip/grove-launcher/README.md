# Grove Launcher

An Android 12+ launcher by GraNet IT Solutions. Version 0.1.5 alpha.

## Build

Install Android Studio, Android SDK 35, and JDK 17. Open this directory, let Gradle sync, then run the app. On Linux:

```sh
export ANDROID_HOME=/path/to/Android/Sdk
./gradlew assembleDebug testDebugUnitTest lintDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Choose Grove in Android's default Home app selector, or use Settings → Set as default launcher. Keep the existing launcher installed; Android Settings → Apps → Default apps → Home app switches back.

## Included

- Home screen with optional clock/date, optional pinned applications, widgets, optional Search button, and optional All apps button. Pinned apps can sit near the top or bottom of Home.
- Home gestures: swipe down to open focused app search and swipe up to open the app drawer; both can be disabled independently. Swipe feedback animates with the gesture, and a downward swipe from the top of the app drawer closes it.
- App drawer and case/accent-insensitive ranked app search.
- Long-press an app to pin/unpin it, arrange pinned apps, open Android app information, or launch Android's uninstall flow. Arrange mode supports drag/drop plus Earlier/Later controls.
- Basic standard Android widget hosting, provider configuration, three height choices, removal, and persistent IDs.
- Material 3 controls with wallpaper-derived dynamic colors where supported.
- Three bundled original procedural wallpapers: Fern, Ember, Dusk.
- Launcher Settings overlay with swipe, tap/context-menu, and home-screen visibility toggles.
- Settings UI plus validated JSON editing/import/export through Android's document picker; version-1/2 configs migrate with existing behavior preserved.
- No telemetry, accounts, background network requests, or Internet permission.
- GitHub Actions build, lint, and search tests.

## Architecture

`MainActivity.kt` owns Android integration and UI. `Config.kt` validates portable settings; widget IDs stay device-local. `Search.kt` contains pure ranking logic. `WallpaperArt.kt` draws bundled artwork locally. Storage is app-private SharedPreferences; configuration is explicitly exported by the user.

Kotlin and native Android Views are used throughout this initial release. Rust is reserved for demonstrated CPU bottlenecks; there is no artificial native bridge or performance claim. App icons and widget contents remain supplied by their respective installed applications.

## Scope and known limitations

This is an initial alpha, not a production 1.0 release. Search currently covers launchable app names. File content, contacts, app shortcuts, work/private profiles, folders, drag-and-drop, icon packs, and recents replacement are not implemented. Favorites preserve pin order. Widgets occupy full-width rows and provide basic height controls rather than a freeform grid. The home background displays the selected artwork with a contrast overlay; selecting a bundled wallpaper also sets the Android system wallpaper. The settings theme follows system day/night settings.

Dependencies are pinned to known compatible versions rather than automatically tracking latest releases. Release signing, Play distribution, and a permanent application ID should be finalized before public distribution. The supplied APK is for testing and uses a development signing key.

See TESTING.md for verification and device acceptance checks.

## License

Apache-2.0. Original source, icon, and wallpaper drawing instructions are included under this license. Android/Google/third-party dependencies retain their own licenses.

## 0.1.4 interaction and cache update

Long-pressing an app now includes an Uninstall action. Android still owns the uninstall confirmation UI; Grove does not request privileged or silent package deletion.

The dedicated Settings button has been removed from Home. The launcher context menu is opened from empty Home space by tap and/or tap-and-hold, controlled independently in Launcher settings. Tap is disabled by default; tap-and-hold is enabled by default.

Home screen settings can now also hide the Search apps button. Together with the existing clock, pinned-app, and All apps toggles, this allows an intentionally near-empty wallpaper-first home screen.

App icons are eagerly decoded during app discovery and retained in memory for the lifetime of the launcher process. The app list is published after the preload pass, so repeatedly opening the drawer does not decode icons on demand. Package changes refresh the catalog, reusing unchanged icons. Bitmaps live in a process-owned cache that survives Activity recreation. The drawer only binds prepared bitmaps. A first-start loading message is shown while preloading.

Configuration schema version 3 stores the two context-menu gesture controls and Search-button visibility. Version-1 and version-2 configurations migrate with existing controls preserved, single-tap context menu disabled, tap-and-hold enabled, and Search visible.

## Reaching settings

Long-press empty home space (default), or enable single-tap to open the launcher context menu. Choose Launcher settings for the Gestures and Home screen sections. There is no dedicated Home Settings button. Single-tap and long-press settings apply only to empty space; app and widget controls keep their own actions.

For a Search-only home: hide clock/date, pinned apps, and All apps, leaving Search enabled. Hide Search too for a wallpaper-only home. Added widgets are managed separately. All options persist and export in JSON.

If both context-menu gestures and all visible controls are disabled, open Grove from another launcher’s app list, or Android's app-specific settings shortcut if available. These explicit app launches open the settings overlay; pressing Home still opens the home screen.

The 0.1.4 APK is a normal Gradle-built Android app. It supersedes the prior offline compatibility APK. The build environment's previous development signing key was unavailable; this build has a new development certificate. An installed alpha signed with the previous certificate must be uninstalled before installing this APK. Export settings first if needed. The development signing backup is separate from the public source archive.


## 0.1.5 polish and pinned-app arrangement

Home and drawer transitions now animate instead of snapping between states. Home swipe gestures provide lightweight movement feedback, while the app drawer follows a downward pull and settles back when the close threshold is not reached. The drawer only accepts this close gesture when the touch starts on the app grid while the grid is already at its top.

Pinned apps now have an Arrange mode. Each pinned app exposes Earlier/Later controls, plus a dedicated drag handle. Dragging over another row highlights that drop target; dropping reorders the persistent favorites list. The existing long-press app menu remains available and links into Arrange mode for already-pinned apps.

Launcher settings adds **Pinned apps at bottom**. Enabled keeps pins after widgets and immediately above All apps; disabled moves pins directly below the clock/search area and before widgets. Configuration schema version 4 persists this choice, and version 1–3 imports keep the prior bottom placement by default.
