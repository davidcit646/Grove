# Grove 0.1.5-alpha — source status

This source package is based on the last verified Grove 0.1.4 build and adds the requested polish/reordering pass.

## Added in 0.1.5-alpha

- Animated Home ↔ drawer transitions and swipe movement feedback.
- Pull-down-to-close behavior in the app drawer. The close gesture is accepted only when it begins on the app grid while the grid is already at the top.
- Pinned-app Arrange mode with drag/drop, highlighted drop targets, and Earlier/Later controls.
- Persistent pinned-app ordering.
- `Pinned apps at bottom` launcher setting. When enabled, pins stay after widgets and above All apps; when disabled, pins appear below the clock/search area and before widgets.
- Configuration schema version 4 with migration from versions 1–3.
- Pure Kotlin ordering and drawer-gesture tests added.

## Verification state

The underlying 0.1.4 source previously passed `assembleDebug`, `testDebugUnitTest`, and `lintDebug` with 23 unit tests and zero lint errors.

For this 0.1.5 source package, pure Kotlin gesture/order helper source was syntax-compiled locally. The full Android Gradle build could not be rerun in this packaging environment because the Gradle distribution was not available offline. The included GitHub Actions workflow runs:

```sh
./gradlew assembleDebug testDebugUnitTest lintDebug
```

Use the Actions result as the authoritative build verification after upload.
